package autofficina;

import java.util.Objects;

public class Macchina {
	
	private String nome;
	private int cilindrata;
	private String targa;
	private int prezzo;
	private String colore;
	private int numeroMarce;
	private boolean motoreAcceso;
	private int marcia;

	public boolean isMotoreAcceso() {
		return motoreAcceso;
	}
	
	public void setMotoreAcceso(boolean motoreAcceso) {
		this.motoreAcceso = motoreAcceso;
	}
	
	public int getMarcia() {
		return marcia;
	}
	
	public void setMarcia(int marcia) {
		if(marcia <= numeroMarce) {
			this.marcia = marcia;
			System.out.println("Ho impostato la marcia a " + marcia);
		} else {
			this.marcia = 0;
			System.out.println("La marcia scelt� e piu alta del limite, marcia impostata a 0");
		}
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public int getCilindrata() {
		return cilindrata;
	}
	
	public void setCilindrata(int cilindrata) {
		this.cilindrata = cilindrata;
	}
	
	public String getTarga() {
		return targa;
	}
	
	public void setTarga(String targa) {
		this.targa = targa;
	}
	
	public int getPrezzo() {
		return prezzo;
	}
	
	public void setPrezzo(int prezzo) {
		this.prezzo = prezzo;
	}
	
	public String getColore() {
		return colore;
	}
	
	public void setColore(String colore) {
		this.colore = colore;
	}
	
	public int getNumeroMarce() {
		return numeroMarce;
	}
	
	public void setNumeroMarce(int numeroMarce) {
		this.numeroMarce = numeroMarce;
	}
	
	
	public void accendiMotore() {
		if (this.motoreAcceso == false) {
			this.motoreAcceso = true;
			System.out.println("Ho acceso il motore!");
		} else {
			System.out.println("Il motore � gi� accesso!");
		}
	}
	
	public void spegniMotore() {
		if (this.motoreAcceso == true) {
			this.motoreAcceso = false;
			System.out.println("Ho spento il motore!");
			setMarcia(0);
		} else {
			System.out.println("Il motore � gi� spento!");
		}
	}
	
	public void cambiaMarcia(int numeroMarcia) {
		if (this.marcia != numeroMarcia) {
			setMarcia(numeroMarcia);
		} else {
			System.out.println("La marcia scelta � gi� inserita");
		}
	}
	
	public void scalaMarcia() {
		if(this.marcia != 0) {
			this.marcia--;
			System.out.println("Ho scalato la marcia a " + this.marcia);
		} else {
			System.out.println("La marcia � gi� al minimo");
		}
	}
	
	public void aumentaMarcia() {
		if (this.marcia <= this.numeroMarce) {
			this.marcia++;
			System.out.println("Ho aumentato la marcia a " + this.marcia);
		} else {
			System.out.println("La marcia � gi� al massimo");
		}
	}
	
	public void getValore() {
		System.out.println("Il prezzo dell'auto � di: " + this.prezzo + " euro");
	}

	public Macchina(String nome, int cilindrata, String targa, int prezzo, String colore, int numeroMarce,
			boolean motoreAcceso, int marcia) {
		super();
		this.nome = nome;
		this.cilindrata = cilindrata;
		this.targa = targa;
		this.prezzo = prezzo;
		this.colore = colore;
		this.numeroMarce = numeroMarce;
		this.motoreAcceso = motoreAcceso;
		this.marcia = marcia;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Macchina other = (Macchina) obj;
		return cilindrata == other.cilindrata && Objects.equals(colore, other.colore) && marcia == other.marcia
				&& motoreAcceso == other.motoreAcceso && Objects.equals(nome, other.nome)
				&& numeroMarce == other.numeroMarce && prezzo == other.prezzo && Objects.equals(targa, other.targa);
	}

	@Override
	public String toString() {
		return "Nome =  " + nome + ", \nCilindrata = " + cilindrata + ", \nTarga = " + targa + ", \nPrezzo = " + prezzo
				+ ", \nColore = " + colore + ", \nNumero Marce = " + numeroMarce + ", \nMotore Acceso = " + motoreAcceso + ", \nMarcia = "
				+ marcia;
	}

}
