package autofficina;

public class Main {

	public static void main(String[] args) {	
	Macchina[] officina = {
			new Macchina("Fiat", 300, "U1F2F3A4", 3000, "bianco", 5, false, 0),
			new Macchina("Lamborghini", 550, "A3T9F3F9", 250000, "verde", 6, true, 2),
			new Macchina("Ferrari", 750, "U6F9S6B9N", 350000, "rosso", 6, true, 3),
			new Macchina("Clio", 350, "B7V4G5H8J", 28000, "blu", 5, false, 0),
			new Macchina("BMW", 450, "J7H5Y4U3I", 150000, "bianco", 6, true, 1)};	
		
		officina[1].spegniMotore();
		System.out.println("\n");
		officina[2].aumentaMarcia();
		System.out.println("\n");
		officina[3].cambiaMarcia(2);
		System.out.println("\n");
		officina[4].getValore();
		System.out.println("\n");
		macchinaPiuCostosa(officina);
		System.out.println("\n");
		infoMacchina(officina, "A3T9F3F9");
		System.out.println("\n");
		infoMacchinaColore(officina, "BIANCO");
		
	}
	
	
	static void macchinaPiuCostosa(Macchina[] officina) {
		int macchinaPiuCostosa = 0;
		
		if(officina.length != 0) {
			for (int i = 0; i < officina.length; i++) {
				if(officina[i].getPrezzo() >= officina[macchinaPiuCostosa].getPrezzo()) {
					macchinaPiuCostosa = i;
				}
			}
			System.out.println("La macchina piu' costosa e':\n" + officina[macchinaPiuCostosa].toString());
		} else {
			System.out.println("Nessuna macchina trovata");
		}
	}


	static void infoMacchina(Macchina[] officina, String targa) {
		boolean trovata = false;	
		
		for (int i = 0; i < officina.length; i++) {
			if (officina[i].getTarga().toUpperCase().equals(targa.toUpperCase()) ) {
				System.out.println("Info della macchina con targa: " + targa);
				System.out.println(officina[i].toString());
				trovata = true;
			}
		}
		if (!trovata) {
			System.out.println("Nessuna macchina trovata con la targa: " + targa);
		}
	}
	
	static void infoMacchinaColore(Macchina[] officina, String colore) {
		boolean trovata = false;	
		
		for (int i = 0; i < officina.length; i++) {
			if (officina[i].getColore().toLowerCase().equals(colore.toLowerCase()) ) {
				System.out.println("Ho trovato questa macchina di colore: " + colore);
				System.out.println(officina[i].toString());
				trovata = true;
				System.out.println("\n");
			}
		}		
		if (!trovata) {
			System.out.println("Nessuna macchina trovata di colore: " + colore);
		}
	}


}